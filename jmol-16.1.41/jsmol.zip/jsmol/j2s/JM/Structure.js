Clazz.declarePackage ("JM");
Clazz.declareInterface (JM, "Structure");

Clazz.declarePackage ("JS");
Clazz.load (["JS.JComponent"], "JS.JComponentImp", null, function () {
c$ = Clazz.declareType (JS, "JComponentImp", JS.JComponent);
Clazz.overrideMethod (c$, "toHTML", 
function () {
return null;
});
});
